package com.example.puzzle;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.GridLayout;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Button[][] buttons;
    private int emptyRow, emptyCol;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        GridLayout gridLayout = findViewById(R.id.gridLayout);
        initializePuzzle(gridLayout);
    }

    private void initializePuzzle(GridLayout gridLayout) {
        buttons = new Button[3][3];
        List<Integer> numbers = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 0));
        Collections.shuffle(numbers);

        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                Button button = new Button(this);
                int number = numbers.remove(0);
                button.setText(number == 0 ? "" : String.valueOf(number));

                // Create final variables to capture the values of row and col
                final int finalRow = row;
                final int finalCol = col;

                button.setOnClickListener(view -> onTileClick(finalRow, finalCol));
                buttons[row][col] = button;

                GridLayout.Spec rowSpec = GridLayout.spec(row);
                GridLayout.Spec colSpec = GridLayout.spec(col);
                GridLayout.LayoutParams params = new GridLayout.LayoutParams(rowSpec, colSpec);
                params.width = 0;
                params.height = GridLayout.LayoutParams.WRAP_CONTENT;
                button.setLayoutParams(params);

                gridLayout.addView(button);
            }
        }

        emptyRow = 2;
        emptyCol = 2;
    }


    private void onTileClick(int row, int col) {
        // Handle tile click event
        // Check if the clicked tile can be moved, update positions, and check if the puzzle is solved
    }
}

